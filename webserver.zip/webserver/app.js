"use strict";

var express = require("express");
var compression = require('compression');

var cors = require('cors');

var app = express();
const map = new Map();
const fs = require("fs");
const content = fs.readFileSync("./start.html", 'utf8');

app.use(cors());
app.use(compression({ filter: shouldCompress }))

function shouldCompress (req, res) {
  if (req.headers['x-no-compression']) {
    // don't compress responses with this request header
    return false
  }

  // fallback to standard filter function
  return compression.filter(req, res)
}

app.get('/test', function (req, res) {
    res.writeHead(200);
    res.end("ok");
});

app.get('/start', function (req, res) {
    res.send(content.replace(/111/g, req.query.id));
});

app.get('/write', function (req, res) {
    var id = req.query.id;
    if(!id.match(/^\s*\d\d?\d?\s*$/)) {
        res.end("Must be a number between 0 and 1000");
        return;
    }
    map.set(req.query.id, req.query.o);
//    console.info(map);
    res.send("ok");
});


app.get('/read', function (req, res) {
    res.send(map.get(req.query.id));
});
// app.get('/read', async function (req, res) {
//     for(var i=0; i < 1000; ++i) {
//         var r = map.delete(req.query.id)
//         if(r != null) {
//             res.send(r);
//             return;
//         }
//         await new Promise(resolve => setTimeout(resolve, 10));
//     }
//     res.send("");
// });
// DO NOT DO app.listen() unless we're testing this directly
if (require.main === module) {
    app.listen(3000);
}

// Instead do export the app:
module.exports = app;